﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMMON
{
    public enum GridMode
    {
        EDIT,
        EDITEND,
        EDITCONTINUE
    }

    public enum STPReport
    {

    }

    public enum DBErrorNumbers
    {
        ApplicationError = -20001
    }

    public enum ReportFormat
    {
        EXCEL,
        PDF
    }

    //public enum FileFormat
    //{
    //    EXCEL,
    //    PDF
    //}
}
